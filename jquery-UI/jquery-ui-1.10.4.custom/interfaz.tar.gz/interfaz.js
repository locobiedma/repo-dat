$(function() {
	$( "#draggable" ).draggable();
});

$(function() {
	$( "#selectable" ).selectable();
});

$(function() {
	$( "#sortable" ).sortable();
	$( "#sortable" ).disableSelection();
});

$(function() {
	$( "#datepicker" ).datepicker();
});

$(function() {
	$( document ).tooltip();
});
